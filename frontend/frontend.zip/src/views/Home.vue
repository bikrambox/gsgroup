<template>
  <div class="home">
    <header>
      <div id="account">
        <div v-if="isAuthenticated">
          <div id="auth">
            Authenticated as "{{ user.username }}" &lt;{{ user.email }}&gt;
          </div>
        </div>
        <div v-else>
          <router-link to="/login" class="login">Login</router-link>
        </div>
      </div>
      <h1>Care4all API</h1>
    </header>

    <main>
      <nav>
        <ul>
          <li><router-link to="/documentation">Documentation</router-link></li>
          <li><router-link to="/account">Account</router-link></li>
          <li><router-link to="/users">Users</router-link></li>
          <li><router-link to="/clients">Clients</router-link></li>
          <li><router-link to="/collections">Collections</router-link></li>
          <li><router-link to="/customers">Customers</router-link></li>
          <li><router-link to="/groups">Groups</router-link></li>
          <li><router-link to="/units">Units</router-link></li>
          <li><router-link to="/calendars">Calendars</router-link></li>
          <li><router-link to="/configurations">Configurations</router-link></li>
          <li><router-link to="/waypoints">Waypoints</router-link></li>
          <li><router-link to="/geozones">Geozones</router-link></li>
          <li><router-link to="/images">Images</router-link></li>
          <li><router-link to="/icons">Icons</router-link></li>
          <li><router-link to="/invites">Invites</router-link></li>
          <li><router-link to="/positions">Positions</router-link></li>
          <li><router-link to="/temperatures">Temperatures</router-link></li>
          <li><router-link to="/events">Events</router-link></li>
          <li><router-link to="/sutmessages">Sutmessages</router-link></li>
          <li><router-link to="/generic-data">Generic data</router-link></li>
          <li><router-link to="/fms-data">FMS data</router-link></li>
          <li><router-link to="/messages">Messages</router-link></li>
          <li><router-link to="/tasks">Tasks</router-link></li>
          <li><router-link to="/drivers">Drivers</router-link></li>
          <li><router-link to="/tags">Tags</router-link></li>
        </ul>
      </nav>
      <article>
        <section>
          <p v-if="isAuthenticated">Hello, {{ user.username }}!</p>
          <p v-else>Welcome to Care4all API!</p>
        </section>
      </article>
    </main>

    <footer>© {{ currentYear }} Flextrack ApS</footer>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useAuthStore } from '../stores/auth'

const auth = useAuthStore()
const isAuthenticated = computed(() => auth.isAuthenticated)
const user = computed(() => auth.user)
const currentYear = new Date().getFullYear()
</script>

<style scoped>
.home {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', system-ui;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

header {
  margin-bottom: 30px;
}

#account {
  text-align: right;
  margin-bottom: 20px;
}

nav ul {
  list-style: none;
  padding: 0;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 10px;
}

nav a {
  display: block;
  padding: 10px;
  text-decoration: none;
  color: #333;
  background: #f5f5f5;
  border-radius: 4px;
  transition: background 0.3s;
}

nav a:hover {
  background: #e0e0e0;
}

footer {
  margin-top: 40px;
  text-align: center;
  color: #666;
}
</style>
